package adapterpattern;

public class Square {
    public void pay(double amount) {
        System.out.println("Paying $" + amount + " through Square.");
    }
}

