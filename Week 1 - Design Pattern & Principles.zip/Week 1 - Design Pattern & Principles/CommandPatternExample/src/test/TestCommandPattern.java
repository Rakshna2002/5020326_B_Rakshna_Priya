package test;

import commands.LightOffCommand;
import commands.LightOnCommand;
import invoker.RemoteControl;
import receiver.Light;

public class TestCommandPattern {
    public static void main(String[] args) {
        Light light = new Light();

        LightOnCommand lightOn = new LightOnCommand(light);
        LightOffCommand lightOff = new LightOffCommand(light);

        RemoteControl remote = new RemoteControl();

        // Turn the light on
        remote.setCommand(lightOn);
        remote.pressButton();

        // Turn the light off
        remote.setCommand(lightOff);
        remote.pressButton();
    }
}
