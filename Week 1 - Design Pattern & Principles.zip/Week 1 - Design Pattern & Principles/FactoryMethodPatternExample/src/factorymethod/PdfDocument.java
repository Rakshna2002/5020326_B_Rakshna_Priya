package factorymethod;

public interface PdfDocument {
    void open();
    void save();
}