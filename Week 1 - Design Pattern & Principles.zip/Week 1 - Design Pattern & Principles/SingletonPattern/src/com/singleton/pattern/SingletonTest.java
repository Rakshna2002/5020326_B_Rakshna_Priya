package com.singleton.pattern;

public class SingletonTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Logger l1 = Logger.getInstance();
        Logger l2 = Logger.getInstance();

        if (l1 == l2) {
            System.out.println("Both references point to the same instance");
        } else {
            System.out.println("Different instances are created");
        }

        l1.log("This is the first log message.");
        l2.log("This is the next log message.");
	}

}
