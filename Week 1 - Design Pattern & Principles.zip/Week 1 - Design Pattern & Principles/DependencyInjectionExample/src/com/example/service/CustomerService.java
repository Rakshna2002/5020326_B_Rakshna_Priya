package com.example.service;

import com.example.repository.CustomerRepository;

public class CustomerService {
    private final CustomerRepository customerRepository;

    // Constructor Injection
    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public String getCustomerById(int id) {
        return customerRepository.findCustomerById(id);
    }
}
