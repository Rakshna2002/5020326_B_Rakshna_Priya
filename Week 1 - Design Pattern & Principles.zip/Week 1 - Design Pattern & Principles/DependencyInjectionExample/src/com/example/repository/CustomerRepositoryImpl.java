package com.example.repository;

public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public String findCustomerById(int id) {
        // For demonstration, returning a dummy customer name
        return "Customer" + id;
    }
}
