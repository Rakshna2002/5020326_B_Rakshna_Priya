package decoratorpattern;

public interface Notifier {
    void send(String message);
}

