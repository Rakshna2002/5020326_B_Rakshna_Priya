package decoratorpattern;

public class Main {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier);
        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);

        String message = "Hello, this is a test notification.";

        System.out.println("Sending notifications via multiple channels:");
        slackNotifier.send(message);
    }
}

