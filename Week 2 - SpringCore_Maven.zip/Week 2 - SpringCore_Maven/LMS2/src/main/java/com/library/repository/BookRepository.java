package com.library.repository;

public class BookRepository {

    public BookRepository() {
        System.out.println("Book repository is now operational.");
    }

    public void performRepositoryOperation() {
        System.out.println("Performing repository operation.");
    }
}
