package com.library.management;

import java.util.Arrays;

public class Library {
	
	private Book[] books;
	private int count;
	
	public Library(int capacity) {
		books=new Book[capacity];
		count=0;
	}
	
	public void addBook(Book book) {
		if(count>=books.length) {
			System.out.println("Can't add any more books");
			return;
		}
		books[count++]=book;
	}
	
	public Book linearSearchByTitle(String title) {
        for (int i = 0; i < count; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                return books[i];
            }
        }
        return null;
    }
	
	public Book binarySearchByTitle(String title) {
        Arrays.sort(books, 0, count, (a, b) -> a.getTitle().compareToIgnoreCase(b.getTitle()));
        int left = 0;
        int right = count - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = books[mid].getTitle().compareToIgnoreCase(title);
            if (comparison == 0) {
                return books[mid];
            }
            if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }
	
	public void printAllBooks() {
        for (int i = 0; i < count; i++) {
            System.out.println(books[i]);
        }
    }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Library library = new Library(10);

        // Adding books
        library.addBook(new Book(1, "The Seven Husbands of Evelyn", "Taylor Jenkins Reid\r\n"
        		+ ""));
        library.addBook(new Book(2, "Never lie", "Freida McFadden"));
        library.addBook(new Book(3, "To Kill a Mockingbird", "Harper Lee"));

        // Linear search for a book
        String searchTitle = "Never lie";
        Book foundBook = library.linearSearchByTitle(searchTitle);
        System.out.println("Linear Search - Book found: " + foundBook);

        // Binary search for a book
        foundBook = library.binarySearchByTitle(searchTitle);
        System.out.println("Binary Search - Book found: " + foundBook);

        // Print all books
        System.out.println("All books in the library:");
        library.printAllBooks();
    }
}
