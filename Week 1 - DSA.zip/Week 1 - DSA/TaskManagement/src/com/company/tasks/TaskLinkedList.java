package com.company.tasks;

class Node{
	Task task;
	Node next;
	
	Node(Task task){
		this.task=task;
		this.next=null;
	}
}

public class TaskLinkedList {
	private Node head;
	
	public TaskLinkedList() {
		this.head=null;
	}
	
	public void addTask(Task task) {
		Node newNode=new Node(task);
		if(head==null) {
			head=newNode;
		}else {
			Node curr=head;
			while(curr.next!=null) {
				curr=curr.next;
			}
			curr.next=newNode;
		}
	}
	
	public Task searchTask(int taskId) {
		Node curr=head;
		while(curr!=null) {
			if(curr.task.getTaskId()==taskId) {
				return curr.task;
			}
			curr=curr.next;
		}
		return null;
	}
	
	public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }
	
	public boolean deleteTask(int taskId) {
		if(head== null) return false;
		if(head.task.getTaskId()==taskId) {
			head=head.next;
			return true;
		}
		Node curr=head;
		while(curr!=null) {
			if(curr.next.task.getTaskId()==taskId) {
				curr.next=curr.next.next;
				return true;
			}
			curr=curr.next;
		}
		return false;
	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TaskLinkedList taskList = new TaskLinkedList();

        taskList.addTask(new Task(1, "Design Database", "Pending"));
        taskList.addTask(new Task(2, "Develop Backend", "In Progress"));
        taskList.addTask(new Task(3, "Create UI", "Pending"));

        System.out.println("All Tasks:");
        taskList.traverseTasks();

        int searchId = 2;
        Task task = taskList.searchTask(searchId);
        System.out.println("Task with ID " + searchId + ": " + task);

        int deleteId = 1;
        boolean deleted = taskList.deleteTask(deleteId);
        System.out.println("Task with ID " + deleteId + " deleted: " + deleted);

        System.out.println("All Tasks after deletion:");
        taskList.traverseTasks();
    }

}
