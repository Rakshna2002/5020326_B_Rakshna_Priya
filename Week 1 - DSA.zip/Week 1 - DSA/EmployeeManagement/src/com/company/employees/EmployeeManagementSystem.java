package com.company.employees;

public class EmployeeManagementSystem {

	private Employee[] employees;
	private int count;
	
	public EmployeeManagementSystem(int capacity) {
		employees=new Employee[capacity];
		count=0;
	}

	public boolean addEmp(Employee employee) {
		if(count>=employees.length) {
			System.out.println("Can't add employees - Array is full");
			return  false;
		}
		employees[count++]=employee;
		return true;
	}
	
	public Employee searchEmp(int employeeID) {
		for(int i=0;i<count;i++) {
			if(employees[i].getEmployeeId()==employeeID) {
				return employees[i];
			}
		}
		return null;
	}
	
    public void traverseEmp() {
        for (int i = 0; i < count; i++) {
            System.out.println(employees[i]);
        }
    }
	
	public boolean deleteEmp(int employeeID) {
		for(int i=0;i<count;i++) {
			if(employees[i].getEmployeeId()==employeeID) {
				for(int j=0;j<count;j++) {
					employees[j]=employees[j+1];
				}
				employees[--count]=null;
				return true;
			}
		}
		return false;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeManagementSystem ems = new EmployeeManagementSystem(10);

        ems.addEmp(new Employee(1, "Azar", "AWS Expert", 75000));
        ems.addEmp(new Employee(2, "Hiru", "SE Developer", 60000));
        ems.addEmp(new Employee(3, "Kunaiya", "UX Designer", 55000));

        System.out.println("All Employees:");
        ems.traverseEmp(); 

        int searchId = 2;
        Employee emp = ems.searchEmp(searchId);
        System.out.println("Employee with ID " + searchId + ": " + emp);

        int deleteId = 1;
        boolean deleted = ems.deleteEmp(deleteId);
        System.out.println("Employee with ID " + deleteId + " deleted: " + deleted);

        System.out.println("All Employees after deletion:");
        ems.traverseEmp();
	}

}
