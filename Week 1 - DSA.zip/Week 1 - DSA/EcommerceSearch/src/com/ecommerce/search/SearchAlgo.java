package com.ecommerce.search;

import java.util.Arrays;
import java.util.Comparator;;

public class SearchAlgo {
	public static Product linearSearch(Product[] products, String productName) {
		for(Product p:products) {
			if(p.getProductName().equalsIgnoreCase(productName)) {
				return p; //Linear Search
			}
		}
		return null;
	}
	
	public static Product binarySearch(Product[] products, String productName) {
		int left=0;
		int right=products.length-1;
		
		while(left<=right) {
			int mid=left+(right-left)/2;
			int comparison = products[mid].getProductName().compareToIgnoreCase(productName);
			
			if (comparison == 0) {
                return products[mid];
            }
			
            if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
	}
	public static void sortProductsByName(Product[] products) {
        Arrays.sort(products, Comparator.comparing(Product::getProductName));
    }
}
