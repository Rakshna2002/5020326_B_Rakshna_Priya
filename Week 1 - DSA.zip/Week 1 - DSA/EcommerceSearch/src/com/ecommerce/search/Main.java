package com.ecommerce.search;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product[] products = {
        	new Product("1", "Laptop", "Electronics"),
            new Product("2", "Tablet", "Electronics"),
            new Product("3", "Headphones", "Accessories"),
            new Product("4", "Charger", "Accessories")
        };
       // Linear search
       Product foundProduct = SearchAlgo.linearSearch(products, "Charger");
       if (foundProduct != null) {
    	   System.out.println("Product found: " + foundProduct.getProductName());
       } else {
           System.out.println("Product not found");
       }

       // Sort products for binary search
       SearchAlgo.sortProductsByName(products);

       // Binary search
       foundProduct = SearchAlgo.binarySearch(products, "Laptop");
       if (foundProduct != null) {
           System.out.println("Product found: " + foundProduct.getProductName());
       } else {
           System.out.println("Product not found");
       }
	}

}
