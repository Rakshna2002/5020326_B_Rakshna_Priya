package inventory;

import java.util.HashMap;

public class InventoryManagementSystem {
	private HashMap<String, Product> inventory;
	
	public InventoryManagementSystem() {
		inventory=new HashMap<>();
	}
		
	public void addProduct(Product product) {
		inventory.put(product.getProductId(), product);
	}
		
	public void updateProduct(Product product) {
		if(inventory.containsKey(product.getProductId())){
			inventory.put(product.getProductId(), product);
		} else {
			System.out.println("Product not found");
		}
	}
		
	public void removeProduct(String productId) {
		if(inventory.containsKey(productId)){
			inventory.remove(productId);
		} else {
			System.out.println("Product not found");
		}
	}
		
	public Product getProduct(String productId) {
		return inventory.get(productId);
	}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InventoryManagementSystem ims = new InventoryManagementSystem();

        // Add products
        Product p1 = new Product("P1", "Product 1", 10, 100.0);
        Product p2 = new Product("P2", "Product 2", 20, 200.0);
        ims.addProduct(p1);
        ims.addProduct(p2);
        
        Product retrievedProduct = ims.getProduct("P1");
        if (retrievedProduct != null) {
            System.out.println("Product ID: " + retrievedProduct.getProductId());
            System.out.println("Product Name: " + retrievedProduct.getProductName());
            System.out.println("Quantity: " + retrievedProduct.getQuantity());
            System.out.println("Price: " + retrievedProduct.getPrice());
        } else {
            System.out.println("Product not found.");
        }
	}

}
